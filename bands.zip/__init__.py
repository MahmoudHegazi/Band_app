#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from flask import render_template, request
from flask_sqlalchemy import SQLAlchemy
from db_class import Band, Event, db, app
import requests
import os
import os
from flask import Flask, flash, request, redirect, url_for
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'static'
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])
#ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])


app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/add_events')
def events():
    bands = Band.query.all()
    return render_template('events.html',bands=bands)

@app.route('/bands_list')
def bands_list():
    bands = Band.query.all()
    return render_template('bands_list.html',bands=bands)

@app.route('/events_list')
def events_list():
    events = Event.query.all()
    return render_template('events_list.html',events=events)


@app.route('/ok', methods=['POST'])
def ader():

    if request.method == 'POST':
        # image part
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        band = request.form['band']
        title = request.form['title']
        file1 = request.files['file1']
        band1 = request.form['band1']
        title1 = request.form['title1']
        # if user does not select file, browser also
        # submit a empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file1.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and file.filename:
            filename = file.filename
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            url=UPLOAD_FOLDER+'/'+filename
        if file1 and file1.filename:
            filename1 = file1.filename
            file1.save(os.path.join(app.config['UPLOAD_FOLDER'], filename1))
            url1=UPLOAD_FOLDER+'/'+filename1
        if url and band and title:
            newband = Band(name=band,image=url,title=title,)
            db.session.add(newband)
            db.session.commit()
        if url1 and band1 and title1:
            newband1 = Band(name=band1,image=url1,title=title1,)
            db.session.add(newband1)
            db.session.commit()
            db.session.close()
            message_html = '<h2>Band: {}</h2><h5>Title: {}</h5><h4>Image: </h4><img src="{}" alt="{}" style="margin-left:auto;margin-right:auto;">'.format(request.form['band'],request.form['title'],url,request.form['band'])
            message_html += '<br /><br /><hr /><h2>Band: {}</h2><h5>Title: {}</h5><h4>Image: </h4><img src="{}" alt="{}" style="margin-left:auto;margin-right:auto;">'.format(request.form['band1'],request.form['title1'],url1,request.form['band1'])
            return message_html
        return redirect(url_for('index', message="image_not_added"))
    return False




@app.route('/event', methods=['POST','GET'])
def event():

    if request.method == 'POST':
        # image part
        # check if the post request has the file part
        if 'image' not in request.files:
            flash('No iamge 1 part')
            return 'No iamge 1 part'
        event_image = request.files['image']
        event_name = request.form['name']
        event_date = request.form['date']
        band_id = request.form['band_id']
        event_image1 = request.files['image1']
        event_name1 = request.form['name1']
        event_date1 = request.form['date1']
        band_id1 = request.form['band_id1']
        # if user does not select file, browser also
        # submit a empty part without filename
        if event_image.filename == '':
            flash('Image 1 No selected file')
            return str(event_image)
        if event_image1.filename == '':
            flash('Image 2 No selected file')
            return str(event_image1)
        if event_image and event_image.filename:
            filename = event_image.filename
            event_image.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            url=UPLOAD_FOLDER+'/'+filename

        if event_image1 and event_image1.filename:
            filename1 = event_image1.filename
            event_image1.save(os.path.join(app.config['UPLOAD_FOLDER'], filename1))
            url1=UPLOAD_FOLDER+'/'+filename1
        if url and event_name and event_date and band_id:
            newEvent = Event(name=event_name,image=url,date=event_date,band_id=band_id)
            db.session.add(newEvent)
            db.session.commit()
            print('event1 added')
        if url1 and event_name1 and event_date1 and band_id1:
            newEvent1 = Event(name=event_name1,image=url1,date=event_date1,band_id=band_id1)
            db.session.add(newEvent1)
            db.session.commit()
            db.session.close()
            print('event2 added')
            message_html = '<h2>Congratulation You Added Some New Events ..</h2><p>Thanks For Bulding our Website</p>'
            message_html += '<h2>Event Name: {}</h2><h4>Event Image: </h4><p>Event Date: {}</p><img src="{}" alt="{}" style="margin-left:auto;margin-right:auto;"><h5>Band_id: {}</h5>'.format(event_name,event_date,url,event_name,band_id)
            message_html += '<br /><br /><hr /><h2>Event Name: {}</h2><p>Event Date: {}</p><h4>Event Image: </h4><img src="{}" alt="{}" style="margin-left:auto;margin-right:auto;"><h5>Band_id: {}</h5>'.format(event_name1,event_date1,url1,event_name1,band_id1)
            return message_html
        return redirect(url_for('events', message="image_not_added"))
    return str('he')

# like is noob becuase it like filter_by
# Car.query.filter(Car.car.like('BMW')).all()
# search match any exist  use this % some text %
# Car.query.filter(Car.car.match('%bmw%')).all()
#return redirect(request.url)
# session.rollback() cancel the session.add uimportant


if __name__ == '__main__':
    app.secret_key = 'S&Djry636qyye21777346%%^&&&#^$^^y___'
    app.debug = True
    app.run(host='0.0.0.0', port=5000)
